package model;
/**
 * Created by emmalautz on 10/23/16.
 */

public class Category {

    public static String HANDICAPPED = "Handicapped";
    public static String COMPACT = "Compact";
    public static String TRUCK = "Truck";
    public static String SUV = "SUV";
    public static String TANDEM = "Tandem";
    public static String COVERED = "Covered";
}
