package model;
import java.util.Map;
public class Search {


    public static Map<Long, Listing> searchListings(){
        //need to pass in search criteria somehow
        return null;
    }
}
