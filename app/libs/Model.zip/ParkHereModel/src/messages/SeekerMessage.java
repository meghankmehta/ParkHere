package messages;

import java.io.Serializable;

import model.Seeker;

public class SeekerMessage extends Message implements Serializable{
	
	public Seeker seeker;
}
