package messages;

import model.Listing;

public class ListingResult {
	public Listing listing;
	public double distance;
}
